from bs4 import BeautifulSoup
import os

def extract_team_stats(html_folder):
    hockey_data = []  # List to store extracted team stats

    for filename in os.listdir(html_folder):
        if filename.endswith(".html"):
            file_path = os.path.join(html_folder, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                soup = BeautifulSoup(f, "html.parser")

                # Find all rows of the hockey stats table
                rows = soup.find_all("tr", class_="team")  # Adjust class if needed

                for row in rows:
                    columns = row.find_all("td")

                    # Extract data from each column
                    team_name = columns[0].text.strip()
                    year = int(columns[1].text.strip())
                    wins = int(columns[2].text.strip())
                    losses = int(columns[3].text.strip())

                    # Store in structured format
                    hockey_data.append({
                        "Team": team_name,
                        "Year": year,
                        "Wins": wins,
                        "Losses": losses
                    })

    return hockey_data

# Run the extraction function
hockey_stats = extract_team_stats("html_pages")

# Print sample data
for entry in hockey_stats[:5]:
    print(entry)
