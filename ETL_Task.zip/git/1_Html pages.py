import aiohttp
import asyncio
import os

BASE_URL = "https://www.scrapethissite.com/pages/forms/"

HEADERS = {"User-Agent": "Mozilla/5.0"}

async def fetch_html(session, page_number):
    url = f"{BASE_URL}?page={page_number}"
    try:
        async with session.get(url, headers=HEADERS) as response:
            if response.status == 200:
                content = await response.text()
                print(f"✅ Successfully fetched page {page_number}")
                return content
            else:
                print(f"❌ Failed to fetch page {page_number} - Status: {response.status}")
                return None
    except Exception as e:
        print(f"⚠️ Error fetching page {page_number}: {e}")
        return None

async def scrape_and_save():
    os.makedirs("html_pages", exist_ok=True)
    print("📂 Created 'html_pages' folder.")

    async with aiohttp.ClientSession() as session:
        tasks = [fetch_html(session, page) for page in range(1, 25)]
        pages = await asyncio.gather(*tasks)

        for i, html in enumerate(pages, start=1):
            if html:
                filename = f"html_pages/{i}.html"
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(html)
                print(f"💾 Saved {filename}")

# Run the async function
asyncio.run(scrape_and_save())

