import pytest
import sys
import os
from aioresponses import aioresponses
from bs4 import BeautifulSoup

# Ensure the main script is accessible
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

# Import functions from the main script
from etl_main import extract_team_stats, generate_excel

# Mock HTML for testing
MOCK_HTML = """
<table>
    <tr class="team">
        <td>Boston Bruins</td>
        <td>1991</td>
        <td>45</td>
        <td>28</td>
    </tr>
    <tr class="team">
        <td>Chicago Blackhawks</td>
        <td>1991</td>
        <td>47</td>
        <td>25</td>
    </tr>
</table>
"""


@pytest.fixture
def mock_html_file(tmp_path):
    """Creates a temporary HTML file for testing"""
    file_path = tmp_path / "1.html"
    file_path.write_text(MOCK_HTML, encoding="utf-8")
    return str(file_path.parent)  # Return the folder path


def test_extract_team_stats(mock_html_file):
    """Test data extraction from HTML files"""
    hockey_stats = extract_team_stats(mock_html_file)

    assert len(hockey_stats) == 2
    assert hockey_stats[0]["Team"] == "Boston Bruins"
    assert hockey_stats[0]["Year"] == 1991
    assert hockey_stats[0]["Wins"] == 45
    assert hockey_stats[0]["Losses"] == 28

    assert hockey_stats[1]["Team"] == "Chicago Blackhawks"
    assert hockey_stats[1]["Year"] == 1991
    assert hockey_stats[1]["Wins"] == 47
    assert hockey_stats[1]["Losses"] == 25


def test_generate_excel(mock_html_file):
    """Test Excel file generation and save it permanently."""
    hockey_stats = extract_team_stats(mock_html_file)

    # Save the file in the project folder instead of a temp directory
    output_file = os.path.join(os.getcwd(), "test_hockey_stats.xlsx")

    generate_excel(hockey_stats, output_file)

    assert os.path.exists(output_file)  # Ensure file was created
    print(f"🎉 Test Excel file saved at: {output_file}")
