import zipfile
import os


def create_zipfile(output_filename, folder):
    if not os.path.exists(folder):
        print(f"❌ Folder '{folder}' not found! Make sure scraping was successful.")
        return

    print(f"📦 Creating ZIP file: {output_filename}")
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for filename in os.listdir(folder):
            if filename.endswith('.html'):
                file_path = os.path.join(folder, filename)
                zipf.write(file_path, arcname=filename)
                print(f"✅ Added {filename} to ZIP")

    print("🎉 ZIP file created successfully!")


# Run the function to compress files
create_zipfile("hockey_stats_html.zip", "html_pages")
  