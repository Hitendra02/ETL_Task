from bs4 import BeautifulSoup
import os
from openpyxl import Workbook


def extract_team_stats(html_folder):
    """Extract hockey team statistics from saved HTML files."""
    hockey_data = []

    for filename in os.listdir(html_folder):
        if filename.endswith(".html"):
            file_path = os.path.join(html_folder, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                soup = BeautifulSoup(f, "html.parser")
                rows = soup.find_all("tr", class_="team")

                for row in rows:
                    columns = row.find_all("td")
                    if len(columns) < 4:  # Avoid errors if columns are missing
                        continue

                    team_name = columns[0].text.strip()
                    year = int(columns[1].text.strip())
                    wins = int(columns[2].text.strip())
                    losses = int(columns[3].text.strip())

                    hockey_data.append({
                        "Team": team_name,
                        "Year": year,
                        "Wins": wins,
                        "Losses": losses
                    })

    return hockey_data


def generate_excel(hockey_stats, output_filename="hockey_stats.xlsx"):
    """Generate an Excel file with two sheets."""
    wb = Workbook()

    sheet1 = wb.active
    sheet1.title = "NHL Stats 1990-2011"
    sheet1.append(["Team", "Year", "Wins", "Losses"])

    for entry in hockey_stats:
        sheet1.append([entry["Team"], entry["Year"], entry["Wins"], entry["Losses"]])

    sheet2 = wb.create_sheet(title="Winner and Loser per Year")
    sheet2.append(["Year", "Winner", "Winner Num. of Wins", "Loser", "Loser Num. of Wins"])

    yearly_stats = {}

    for entry in hockey_stats:
        year = entry["Year"]
        team = entry["Team"]
        wins = entry["Wins"]

        if year not in yearly_stats:
            yearly_stats[year] = {"winner": (team, wins), "loser": (team, wins)}
        else:
            if wins > yearly_stats[year]["winner"][1]:
                yearly_stats[year]["winner"] = (team, wins)
            if wins < yearly_stats[year]["loser"][1]:
                yearly_stats[year]["loser"] = (team, wins)

    for year, data in sorted(yearly_stats.items()):
        sheet2.append([year, data["winner"][0], data["winner"][1], data["loser"][0], data["loser"][1]])

    wb.save(output_filename)
    print(f"🎉 Excel file '{output_filename}' created successfully!")
